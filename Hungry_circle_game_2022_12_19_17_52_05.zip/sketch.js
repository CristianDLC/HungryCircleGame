let score = 0;

//may not work on safari
// Declare a "SerialPort" object
var serial;
let rock = [];

// fill in the name of your serial port here:
//copy this from the serial control app
var portName = "/dev/tty.usbmodem14101";

//this array will hold transmitted data
var inMessage = [0, 0, 0];

var LR;
var UD;
let XX; //declare object 

function setup() {
   fill('#00A86b');
  createCanvas(400,400);
  textAlign(CENTER);

  XX= new enemy();
  for (let i = 0; i < 5; i++){
  rock[i] = new Rock();
    }
  
  // make an instance of the SerialPort object
  serial = new p5.SerialPort();

  // Get a list the ports available
  // You should have a callback defined to see the results. See gotList, below:
  serial.list();

  // Assuming our Arduino is connected,  open the connection to it
  serial.open(portName);

  // When you get a list of serial ports that are available
  serial.on('list', gotList);

  // When you some data from the serial port
  serial.on('data', gotData);
}


// Got the list of ports
function gotList(thelist) {
  // theList is an array of their names
  for (var i = 0; i < thelist.length; i++) {
    // Display in the console
    // console.log(i + " " + thelist[i]);
  }
}

// Called when there is data available from the serial port
function gotData() {
  var currentString = serial.readLine();  // read the incoming data
  trim(currentString);                    // trim off trailing whitespace
  if (!currentString) return;             // if the incoming string is empty, do no more
  // console.log(currentString);
      inMessage = split(currentString, '&');   // save the currentString to use for the text
}

function draw() {
 console.log(score); 

  
  LR = map(inMessage[0],0,1023,400,0);
  UD = map(inMessage[1],0,1023,400,0);
   fill('#FF0000');
  background(0,150,100);
 
    XX.move();
  XX.display();
  fill(0,0,0);
  for (i = 0; i < 5; i++){
   rock[i].display();
    if(dist(LR,UD,rock[i].x,rock[i].y)< 30){
     // rock[i].x= 200
     // rock[i].y=200
      score =0;
    console.log("gameover");
    }
     
    }
  fill('#964B00')
    // if (inMessage[2] == 1){
    //     fill(random(255),random(255),random(255));
    // }
  // ellipse(width/2, height/2, map(inMessage[0], 0, 1023, 0, width), map(inMessage[1], 0, 1023, 0, height));
    fill('#44a7c4');
  ellipse(LR,UD,50,50);
 textSize(32);
  fill(255,0,0);
  text(score,LR,UD+10);
  fill(255,255,255);
  if(dist(LR,UD, XX.x, XX.y) < 30){
    score++;
    XX.x = random(width);
    XX.y = random(height);
  }
  
}

class Rock {
  constructor(){
    this.x =random(width);
    this.y =random(height);
    this.diameter =random(30,30);
    if (this.x >150 && this.x < 250){
      this.x =random(width);
    }
  }
    display(){
    rect(this.x, this.y, this.diameter, this.diameter);
  }
}
class enemy {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.diameter = random(10,30);
    this.speed = 2;
  }
  move(){
    this.x += random(-this.speed, this.speed);
    this.y += random(-this.speed, this.speed);
  }
  display(){
    rect(this.x, this.y, this.diameter, this.diameter);
  }
}

function mousePressed(){
  serial.write("1");
}
function mouseReleased(){
  serial.write("0");
}